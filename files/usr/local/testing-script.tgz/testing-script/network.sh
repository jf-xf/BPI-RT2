#!/bin/sh

# ================= 配置区 =================
TARGET_IP="10.11.11.11"
TEST_IP="10.11.11.1"
TIMEOUT=15
PORTS="eth0.2 eth0.3 eth0.4 eth0.5"
# ==========================================

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 核心修改：统一清理并返回正确的错误码给总控
cleanup() {
    local exit_code=$1
    echo -e "\n${YELLOW}--- 测试结束，正在恢复网络环境 ---${NC}"
    ifconfig br-lan:test down 2>/dev/null
    brctl delif br-lan eth0.2 2>/dev/null
    brctl addif br-wan eth0.2 2>/dev/null

    # 将实际的退出码传给系统总控
    exit $exit_code
}

# 异常中断时也按失败处理
trap 'cleanup 1' INT TERM

echo -e "${CYAN}🚀 开始以太网接口自动化 FCT 产测${NC}"
echo -e "${YELLOW}--- 初始化测试网络环境 ---${NC}"

# 把输出重定向到 /dev/null，防止命令自身的提示干扰画面
brctl delif br-wan eth0.2 >/dev/null 2>&1
brctl addif br-lan eth0.2 >/dev/null 2>&1
ifconfig br-lan:test $TEST_IP netmask 255.255.255.0 up

echo "初始化成功！路由 IP: $TEST_IP, 目标设备 IP: $TARGET_IP"
echo "=========================================="

for port in $PORTS; do
    echo ""

    # 拔线检测 (防呆)
    echo -ne "${YELLOW}[防呆检测] 请拔下网线，等待网络断开... ${NC}"
    while ping -c 1 -W 1 "$TARGET_IP" > /dev/null 2>&1; do
        echo -ne "."
        sleep 0.5
    done
    echo -e "\n${GREEN}网络已断开，可以进行下一步。${NC}"

    # 插线检测
    echo -e "${YELLOW}[等待操作] 请将网线插入网口: $port ${NC}"
    pass=0
    count=0

    ip neigh flush dev br-lan 2>/dev/null

    while [ "$count" -lt "$TIMEOUT" ]; do
        # 清理当前行的输出 (\r) 并打印倒计时
        printf "\r等待连接中... (剩余 %2d 秒)  " $((TIMEOUT - count))

        if ping -c 1 -W 1 "$TARGET_IP" > /dev/null 2>&1; then
            # 覆盖掉上面那一行的倒计时信息，显得更干净
            printf "\r${GREEN}✅ 网口 %-6s 测试通过！${NC}          \n" "$port"
            pass=1
            break
        fi
        count=$((count + 1))
        sleep 1
    done

    # 只要有一个网口测试失败，立刻中断测试并返回 1 (FAIL)
    if [ "$pass" -eq 0 ]; then
        echo -e "\n${RED}❌ 网口 $port 测试失败 (连续 $TIMEOUT 秒无响应)！${NC}"
        echo "测试中断。"
        cleanup 1
    fi
done

echo -e "\n${GREEN}🎉 所有网口 ($PORTS) 测试全部通过！${NC}"
# 全部网口测完，完美退出返回 0 (PASS)
cleanup 0
