#!/bin/sh

# 确保 debugfs 已经挂载 (通常 OpenWrt 默认已挂载)
mount -t debugfs none /sys/kernel/debug 2>/dev/null

# 定义要备份的系统按键脚本路径
BTN_DIR="/etc/rc.button"
WPS_SCRIPT="$BTN_DIR/wps"
RESET_SCRIPT="$BTN_DIR/reset"
RFKILL_SCRIPT="$BTN_DIR/rfkill" # 部分固件 WPS 会绑在 rfkill 上

# 清理与恢复函数
cleanup() {
    echo -e "\n--- 正在恢复系统按键原功能 ---"
    [ -f "${WPS_SCRIPT}.bak" ] && mv "${WPS_SCRIPT}.bak" "$WPS_SCRIPT"
    [ -f "${RESET_SCRIPT}.bak" ] && mv "${RESET_SCRIPT}.bak" "$RESET_SCRIPT"
    [ -f "${RFKILL_SCRIPT}.bak" ] && mv "${RFKILL_SCRIPT}.bak" "$RFKILL_SCRIPT"
    echo "恢复完成，脚本退出。"
    exit 0
}

# 捕获退出信号 (Ctrl+C, kill, 脚本正常结束等)，执行 cleanup
trap cleanup INT TERM EXIT

echo "--- 正在屏蔽系统原按键功能 ---"
[ -f "$WPS_SCRIPT" ] && mv "$WPS_SCRIPT" "${WPS_SCRIPT}.bak"
[ -f "$RESET_SCRIPT" ] && mv "$RESET_SCRIPT" "${RESET_SCRIPT}.bak"
[ -f "$RFKILL_SCRIPT" ] && mv "$RFKILL_SCRIPT" "${RFKILL_SCRIPT}.bak"

# ----------------- 阶段 1：等待 WPS 按键 -----------------
echo -e "\n[等待操作] 请按下 WPS 按键 (GPIO 34) 以继续..."
while true; do
    # 读取 gpio-34 的状态，判断是否包含 " lo " (因为是 ACTIVE LOW，按下为 lo)
    if grep "gpio-34" /sys/kernel/debug/gpio | grep -q "in  lo"; then
        echo "✅ 检测到 WPS 按键被按下！"
        
        # 等待按键松开，防止连击触发
        while grep "gpio-34" /sys/kernel/debug/gpio | grep -q "in  lo"; do
            sleep 0.1
        done
        echo "WPS 按键已松开，进入下一阶段。"
        break
    fi
    sleep 0.1 # 轮询间隔 100ms，对人手按键来说足够灵敏且不占 CPU
done

# ----------------- 阶段 2：等待 Reset 按键 -----------------
echo -e "\n[等待操作] 请按下 Reset 按键 (GPIO 60) 以继续..."
while true; do
    # 读取 gpio-60 的状态
    if grep "gpio-60" /sys/kernel/debug/gpio | grep -q "in  lo"; then
        echo "✅ 检测到 Reset 按键被按下！"
        
        # 等待按键松开
        while grep "gpio-60" /sys/kernel/debug/gpio | grep -q "in  lo"; do
            sleep 0.1
        done
        echo "Reset 按键已松开。"
        break
    fi
    sleep 0.1
done

echo -e "\n🎉 所有按键测试通过！"
# 脚本执行到这里会自动触发 trap 执行 cleanup 函数