#!/bin/sh

# ================= 配置区 =================
# 接收总控脚本传来的参数 "2.0" 或 "3.0"
TARGET_USB=$1 

MOUNT_DIR="/tmp/usb_test_mnt"
TMP_TEST_FILE="/tmp/current_test.bin"

# 定义等待插入的超时时间（秒）
WAIT_TIMEOUT=30

# 定义 U 盘里的测试文件名
F2_BIN="usb2_test.bin"
F2_MD5="usb2_test.md5"
F3_BIN="usb3_test.bin"
F3_MD5="usb3_test.md5"
# ==========================================

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 核心修改：接收退出码，并将其原样返回给总控
cleanup() {
    local exit_code=$1
    [ -z "$exit_code" ] && exit_code=0
    
    umount "$MOUNT_DIR" 2>/dev/null
    rm -rf "$MOUNT_DIR"
    rm -f "$TMP_TEST_FILE"
    
    exit $exit_code
}

trap 'cleanup 1' INT TERM

get_usb_speed() {
    local block_dev=$1
    local sys_path=$(readlink -f /sys/block/$block_dev)
    local dir="$sys_path"
    while [ "$dir" != "/" ] && [ -n "$dir" ]; do
        if [ -f "$dir/speed" ]; then
            cat "$dir/speed"
            return
        fi
        dir=$(dirname "$dir")
    done
    echo "unknown"
}

wait_for_udisk() {
    local timeout=$1
    local before=$(ls -1 /sys/block/ 2>/dev/null | grep -E '^sd[a-z]$')
    local count=0

    while [ "$count" -lt "$timeout" ]; do
        printf "\r等待 U 盘插入... (剩余 %2d 秒)  " $((timeout - count)) >&2

        local after=$(ls -1 /sys/block/ 2>/dev/null | grep -E '^sd[a-z]$')

        for disk in $after; do
            if ! echo "$before" | grep -qw "$disk"; then
                echo "" >&2 
                sleep 2     
                echo "$disk" 
                return 0
            fi
        done

        sleep 1
        count=$((count + 1))
    done

    echo "" >&2
    return 1
}

do_test_phase() {
    local target_ver=$1
    local expect_speed=$2
    local target_bin=$3
    local target_md5_file=$4

    echo -e "\n=========================================="
    echo -e "${YELLOW}[等待操作] 请插入 USB ${target_ver} 测具 U 盘...${NC}"

    local new_disk=$(wait_for_udisk "$WAIT_TIMEOUT")

    if [ -z "$new_disk" ]; then
        echo -e "${RED}❌ 操作超时！未在 ${WAIT_TIMEOUT} 秒内检测到 U 盘插入。测试失败！${NC}"
        cleanup 1
    fi

    echo -e "✅ 检测到新磁盘: /dev/$new_disk"

    # 1. 测速率
    local speed=$(get_usb_speed "$new_disk")
    echo -e "🔍 底层协商速率: ${CYAN}${speed} Mbps${NC}"

    if [ "$target_ver" = "2.0" ]; then
        if [ "$speed" != "480" ]; then
            echo -e "${RED}❌ 速率异常！期望 2.0 (480Mbps)，实际为 $speed Mbps。${NC}"
            cleanup 1
        fi
    elif [ "$target_ver" = "3.0" ]; then
        if [ "$speed" != "5000" ] && [ "$speed" != "10000" ]; then
            echo -e "${RED}❌ 速率降级！期望 3.0 (>=5000Mbps)，实际为 $speed Mbps。${NC}"
            echo -e "👉 提示: 请检查 3.0 高速差分走线或引脚是否存在虚焊。"
            cleanup 1
        fi
    fi

    # 2. 挂载 U 盘
    local part="${new_disk}1"
    [ ! -e "/dev/$part" ] && part="$new_disk"

    mkdir -p "$MOUNT_DIR"
    umount "/dev/$part" 2>/dev/null
    if ! mount "/dev/$part" "$MOUNT_DIR"; then
        echo -e "${RED}❌ U 盘挂载失败！请确保 U 盘格式为 FAT32 或 exFAT。${NC}"
        cleanup 1
    fi

    # 3. 检查文件是否存在
    if [ ! -f "$MOUNT_DIR/$target_bin" ] || [ ! -f "$MOUNT_DIR/$target_md5_file" ]; then
        echo -e "${RED}❌ U 盘内缺少测试文件！请确保存在 $target_bin 和 $target_md5_file${NC}"
        cleanup 1
    fi

    # 4. 读取黄金哈希值
    local expected_md5=$(cat "$MOUNT_DIR/$target_md5_file" | awk '{print $1}')

    # 5. 拷贝测试
    rm -f "$TMP_TEST_FILE"
    echo -e "${CYAN}💾 正在读取文件进行完整性校验...${NC}"
    cp "$MOUNT_DIR/$target_bin" "$TMP_TEST_FILE"

    # 6. 计算实际哈希
    local actual_md5=$(md5sum "$TMP_TEST_FILE" | awk '{print $1}')

    echo -e "   > 黄金哈希: $expected_md5"
    echo -e "   > 实际哈希: $actual_md5"

    umount "$MOUNT_DIR" 2>/dev/null
    rm -f "$TMP_TEST_FILE"

    if [ "$expected_md5" = "$actual_md5" ]; then
        echo -e "${GREEN}✅ [$target_ver 模式] 数据读取与哈希校验完美通过！${NC}"
    else
        echo -e "${RED}❌ 哈希值不匹配！数据在传输过程中发生损坏！${NC}"
        cleanup 1
    fi

    # 7. 拔出防呆
    echo -e "\n${YELLOW}[防呆检测] 本阶段通过，请彻底拔出 USB $target_ver U 盘...${NC}"
    while [ -e "/sys/block/$new_disk" ]; do
        sleep 0.5
    done
    echo -e "${GREEN}U 盘已彻底拔出。${NC}"
}

# ================= 主程序入口 =================

if [ "$TARGET_USB" = "2.0" ]; then
    do_test_phase "2.0" "480" "$F2_BIN" "$F2_MD5"
elif [ "$TARGET_USB" = "3.0" ]; then
    do_test_phase "3.0" "5000" "$F3_BIN" "$F3_MD5"
else
    echo -e "${RED}❌ 错误: 未传入或传入了不支持的 USB 版本参数 ($TARGET_USB)${NC}"
    cleanup 1
fi

cleanup 0
