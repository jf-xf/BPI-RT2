#!/bin/sh

### LED 测试脚本 (V2.1 - 具备触发器恢复功能) ###

# LED 定义
LED_PWR="LED_PWR_R"
LED_FUN="LED_FUN_G"
LED_SYS="LED_SYS_B"
LEDS="$LED_PWR $LED_FUN $LED_SYS"

# 用于存储备份触发器的临时文件
BAK_DIR="/tmp/led_bak"
mkdir -p $BAK_DIR

# --- 核心修改：清理与恢复函数 ---
cleanup() {
    local exit_code=$1
    echo "--- 正在恢复 LED 初始状态 ---"
    for led in $LEDS; do
        if [ -d "/sys/class/leds/$led" ]; then
            # 关闭当前亮度
            echo 0 > "/sys/class/leds/$led/brightness"
            # 恢复备份的触发器
            if [ -f "$BAK_DIR/$led" ]; then
                orig_trigger=$(cat "$BAK_DIR/$led")
                echo "$orig_trigger" > "/sys/class/leds/$led/trigger" 2>/dev/null
            fi
        fi
    done
    rm -rf $BAK_DIR
    exit $exit_code
}

# 捕获中断信号
trap 'cleanup 1' INT TERM

echo "--- 初始化并备份 LED 状态 ---"
for led in $LEDS; do
    if [ ! -d "/sys/class/leds/$led" ]; then
        echo "错误: 找不到 /sys/class/leds/$led"
        cleanup 1
    fi

    # 备份当前触发器 (提取中括号内的当前活动触发器)
    # 例如：[none] heartbeat mmc0 -> none
    current_trig=$(cat "/sys/class/leds/$led/trigger" | sed 's/.*\[\(.*\)\].*/\1/')
    echo "$current_trig" > "$BAK_DIR/$led"

    # 解除当前触发器并熄灭，准备测试
    echo none > "/sys/class/leds/$led/trigger"
    echo 0 > "/sys/class/leds/$led/brightness"
done

# 阶段 1：流水亮起
echo "--- 阶段1: 分别常亮 1s ---"
for led in $LEDS; do
    echo "[$led] 亮起"
    echo 1 > "/sys/class/leds/$led/brightness"
    sleep 1
    echo 0 > "/sys/class/leds/$led/brightness"
done

# 阶段 2：全亮
echo "--- 阶段2: 三个灯同时亮 ---"
for led in $LEDS; do echo 1 > "/sys/class/leds/$led/brightness"; done
sleep 1
for led in $LEDS; do echo 0 > "/sys/class/leds/$led/brightness"; done

# 阶段 3：闪烁
echo "--- 阶段3: 分别闪烁 2s ---"
for led in $LEDS; do
    echo "[$led] 闪烁中..."
    for i in 1 2 3 4; do
        echo 1 > "/sys/class/leds/$led/brightness"
        sleep 0.25
        echo 0 > "/sys/class/leds/$led/brightness"
        sleep 0.25
    done
done

# ----- 人工确认环节 -----
echo -n "请观察硬件，LED 测试是否正常？[Y/n]: "
read ans
case "$ans" in
    [Nn]*)
        echo "操作员标记为: 失败 (FAIL)"
        cleanup 1
        ;;
    *)
        echo "操作员标记为: 通过 (PASS)"
        cleanup 0
        ;;
esac