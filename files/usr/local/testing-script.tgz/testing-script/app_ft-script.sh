#!/bin/sh

### BPI 路由器产线综合测试总控脚本 (V2.1 - 稳健版) ###

DEBUGFILE=/tmp/factory_test.log
# 动态获取脚本所在目录，增强移植性
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
QUIT=0

# --- 核心修改：恢复系统环境的函数 ---
restore_env() {
    echo "正在恢复系统环境..."
    # 恢复系统底层日志输出，确保控制台 Debug 功能正常
    echo "7 4 1 7" > /proc/sys/kernel/printk
}

# 捕获中断信号（Ctrl+C）和终止信号
trap 'restore_env; exit 1' INT TERM

# 全局系统级静音（屏蔽底层驱动报错，保持产测界面整洁）
echo "1 4 1 7" > /proc/sys/kernel/printk
rm -f $DEBUGFILE

# 定义测试项。格式为：显示名称:脚本文件名:传递参数
TEST_CASES="Button_Test:button:none \
LED_Test:led:none \
GPIO_Test:gpio:none \
Network_Test:network:none \
USB_2.0_Test:usb:2.0 \
USB_3.0_Test:usb:3.0 \
WiFi_2.4G_Test:wifi:2.4G \
WiFi_5G_Test:wifi:5G"

print_line() {
    echo "=========================================================="
}

run_case() {
    local name="$1"
    local file="${SCRIPT_DIR}/$2.sh"
    local arg="$3"

    echo ""
    echo "[正在运行] $name ..."

    if [ -x "$file" ]; then
        if [ "$arg" = "none" ]; then
            "$file" 2>>$DEBUGFILE
        else
            "$file" "$arg" 2>>$DEBUGFILE
        fi
        return $?
    else
        echo "错误: 找不到脚本 $file 或未赋予执行权限"
        return 1
    fi
}

show_menu() {
    clear
    print_line
    echo "           BPI 路由器产线功能测试系统 (V2.1)"
    print_line
    echo "[1] 运行所有测试项目 (Run All Cases)"

    index=2
    for item in $TEST_CASES; do
        name=$(echo "$item" | cut -d: -f1)
        echo "[$index] $name"
        index=$((index+1))
    done

    echo "[$index] 退出系统 (Exit)"
    print_line
}

run_all() {
    RESULTS=""
    for item in $TEST_CASES; do
        name=$(echo "$item" | cut -d: -f1)
        file=$(echo "$item" | cut -d: -f2)
        arg=$(echo "$item" | cut -d: -f3)

        run_case "$name" "$file" "$arg"
        ret=$?
        RESULTS="$RESULTS $name:$ret"
    done

    echo -e "\n\n"
    print_line
    echo "                最终测试报告 (Test Result)"
    print_line
    echo " 项目名称 (Item)                       结果 (Result)"
    echo "----------------------------------------------------------"

    for r in $RESULTS; do
        name=${r%%:*}
        res=${r##*:}
        if [ "$res" -eq 0 ]; then
            printf " %-36s  [\033[32mPASS\033[0m]\n" "$name"
        else
            printf " %-36s  [\033[31mFAIL\033[0m]\n" "$name"
        fi
    done

    print_line
    echo -n "测试完成，按回车键返回菜单..."
    read dummy
}

run_single() {
    choice=$1
    idx=2
    for item in $TEST_CASES; do
        if [ "$idx" -eq "$choice" ]; then
            name=$(echo "$item" | cut -d: -f1)
            file=$(echo "$item" | cut -d: -f2)
            arg=$(echo "$item" | cut -d: -f3)
            run_case "$name" "$file" "$arg"
            ret=$?
            [ "$ret" -eq 0 ] && echo -e "结果: \033[32mPASS\033[0m" || echo -e "结果: \033[31mFAIL\033[0m"
            echo -n "按回车键继续..."
            read dummy
            return
        fi
        idx=$((idx+1))
    done
}

while [ "$QUIT" -eq 0 ]; do
    show_menu
    echo -n "请选择操作: "
    read choice
    case "$choice" in
        1) run_all ;;
        [2-9]) run_single "$choice" ;;
        *)
            max=2
            for item in $TEST_CASES; do max=$((max+1)); done
            if [ "$choice" -eq "$max" ]; then
                QUIT=1
                restore_env
            else
                echo "无效选择"
                sleep 1
            fi
            ;;
    esac
done