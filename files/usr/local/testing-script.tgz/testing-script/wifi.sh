#!/bin/sh

TARGET_BAND=$1 # 接收参数: "2.4G" 或 "5G"

RADIO_24G="phy1"
SSID_24G="BPI_R4_2G_2"
RADIO_5G="phy0"
SSID_5G="BPI_R4_5G_2 " # 注意末尾空格如果还需要的话

WIFI_PWD="bananapi"
TARGET_IP="10.12.1.1"
BOARD_IP="10.12.1.2"

GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

cleanup() {
    local exit_code=$1
    [ -f /tmp/wireless.bak ] && cp /tmp/wireless.bak /etc/config/wireless
    [ -f /tmp/network.bak ] && cp /tmp/network.bak /etc/config/network
    /etc/init.d/network reload >/dev/null 2>&1
    wifi reload >/dev/null 2>&1
    
    # 强制将真实的退出码返回给总控
    exit $exit_code
}

cp /etc/config/wireless /tmp/wireless.bak
cp /etc/config/network /tmp/network.bak

for iface in $(uci show wireless | grep '=wifi-iface' | cut -d'.' -f2 | cut -d'=' -f1); do
    uci set wireless.$iface.disabled='1'
done

uci set network.test_net=interface
uci set network.test_net.proto='static'
uci set network.test_net.ipaddr="$BOARD_IP"
uci set network.test_net.netmask='255.255.255.0'
uci commit
/etc/init.d/network reload >/dev/null 2>&1

run_wifi_test() {
    local radio=$1
    local ssid=$2
    local mode=$3

    echo -e "${CYAN}▶ 开始测试: $mode (网卡: $radio)${NC}"

    uci set wireless.$radio.disabled='0'
    uci set wireless.test_sta=wifi-iface
    uci set wireless.test_sta.device="$radio"
    uci set wireless.test_sta.network='test_net'
    uci set wireless.test_sta.mode='sta'
    uci set wireless.test_sta.ssid="$ssid"
    uci set wireless.test_sta.encryption='psk2+ccmp' 
    uci set wireless.test_sta.key="$WIFI_PWD"
    uci set wireless.test_sta.ieee80211w='0'
    uci commit

    wifi reload >/dev/null 2>&1
    sleep 8
    ifup test_net >/dev/null 2>&1

    local retry=15
    local pass=0
    
    while [ $retry -gt 0 ]; do
        printf "\r📡 正在验证射频链路... (倒计时 %2d 秒)  " $retry
        if ping -c 1 -W 1 $TARGET_IP > /dev/null 2>&1; then
            printf "\r${GREEN}✅ [$mode] 链路打通！Ping 测试通过！${NC}          \n"
            pass=1
            break
        fi
        sleep 1
        retry=$((retry - 1))
    done

    uci delete wireless.test_sta
    uci commit

    if [ "$pass" -eq 0 ]; then
        echo -e "\n${RED}❌ [$mode] 测试超时失败。${NC}"
        return 1
    fi
    return 0
}

# 根据传入的参数决定跑哪个频段
if [ "$TARGET_BAND" = "2.4G" ]; then
    if ! run_wifi_test "$RADIO_24G" "$SSID_24G" "2.4G"; then cleanup 1; fi
elif [ "$TARGET_BAND" = "5G" ]; then
    if ! run_wifi_test "$RADIO_5G" "$SSID_5G" "5G"; then cleanup 1; fi
else
    echo "未知的 WiFi 频段参数: $TARGET_BAND"
    cleanup 1
fi

# 只有完美通过，才以 0 状态码退出
cleanup 0
