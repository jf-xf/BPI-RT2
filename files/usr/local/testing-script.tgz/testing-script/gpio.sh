#!/bin/sh

# ================= 配置区 =================
TEST_GPIOS="2 3 5 30 37 28 36 25"
SPEED=0.2
# ==========================================

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

cleanup() {
    local exit_code=$1
    echo -e "\n${YELLOW}--- 正在释放 GPIO 资源 ---${NC}"
    for pin in $TEST_GPIOS; do
        echo $pin > /sys/class/gpio/unexport 2>/dev/null
    done
    exit $exit_code
}

trap 'cleanup 1' INT TERM

echo -e "${GREEN}开始 GPIO 流水灯测试...${NC}"
echo "涉及引脚: $TEST_GPIOS"

# 1. 初始化所有 GPIO
for pin in $TEST_GPIOS; do
    if [ ! -d /sys/class/gpio/gpio$pin ]; then
        echo $pin > /sys/class/gpio/export 2>/dev/null
    fi
    echo out > /sys/class/gpio/gpio$pin/direction
    echo 0 > /sys/class/gpio/gpio$pin/value
done

# 2. 跑 3 遍流水灯
for i in 1 2 3; do
    echo -e "${YELLOW}第 $i 遍流水展示...${NC}"
    for pin in $TEST_GPIOS; do
        echo 1 > /sys/class/gpio/gpio$pin/value
        sleep $SPEED
        echo 0 > /sys/class/gpio/gpio$pin/value
    done
done

echo -e "${GREEN}流水灯测试完成！${NC}"

# ----- 人工确认环节 -----
echo -n "请观察硬件，测试是否正常？[Y/n]: "
read ans
case "$ans" in
    [Nn]*)
        echo "操作员标记为: 失败 (FAIL)"
        cleanup 1
        ;;
    *)
        echo "操作员标记为: 通过 (PASS)"
        cleanup 0
        ;;
esac
